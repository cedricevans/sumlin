
import React from 'react';
import { Helmet } from 'react-helmet';
import SmoothScroller from '@/components/SmoothScroller';
import ProductsList from '@/components/ProductsList';

const StorePage = () => {
  return (
    <>
      <Helmet>
        <title>Store - Sumlin Family Reunion Raffle Baskets</title>
        <meta name="description" content="Purchase raffle tickets for our amazing gift baskets. Men's BBQ, Women's Spa, and Children's Fun baskets available for just $1 per ticket." />
      </Helmet>

      <section className="section-spacing bg-background pt-24 md:pt-32">
        <div className="container-custom">
          <SmoothScroller>
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-6xl font-bold mb-6">Raffle gift baskets</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Support the Sumlin Family Reunion by purchasing raffle tickets for just $1 each. Three incredible baskets filled with carefully selected items—one lucky winner for each basket.
              </p>
            </div>
          </SmoothScroller>

          <SmoothScroller delay={0.2}>
            <div className="bg-card rounded-2xl p-8 mb-16 shadow-lg max-w-3xl mx-auto border border-border/50">
              <h2 className="text-2xl font-bold mb-6 text-center">How it works</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-xl gradient-gold flex items-center justify-center mb-4 text-foreground font-bold text-2xl shadow-sm">
                    1
                  </div>
                  <h3 className="font-semibold mb-2 text-lg">Add to Cart</h3>
                  <p className="text-sm text-muted-foreground">Select your favorite baskets and add tickets to your cart</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-xl gradient-burgundy flex items-center justify-center mb-4 text-white font-bold text-2xl shadow-sm">
                    2
                  </div>
                  <h3 className="font-semibold mb-2 text-lg">Checkout</h3>
                  <p className="text-sm text-muted-foreground">Pay securely online or choose Cash on Delivery</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-xl gradient-gold flex items-center justify-center mb-4 text-foreground font-bold text-2xl shadow-sm">
                    3
                  </div>
                  <h3 className="font-semibold mb-2 text-lg">Drawing May 9th</h3>
                  <p className="text-sm text-muted-foreground">Winners announced at the reunion</p>
                </div>
              </div>
            </div>
          </SmoothScroller>

          <div className="mb-16">
            <ProductsList />
          </div>

          <SmoothScroller delay={0.4}>
            <div className="mt-16 text-center">
              <div className="bg-muted rounded-2xl p-8 max-w-2xl mx-auto border border-border/50">
                <h3 className="text-2xl font-bold mb-4">Need help?</h3>
                <p className="text-muted-foreground leading-relaxed">
                  If you have any questions about the raffle baskets or the checkout process, please contact any of our family officers listed in the footer.
                </p>
              </div>
            </div>
          </SmoothScroller>
        </div>
      </section>
    </>
  );
};

export default StorePage;

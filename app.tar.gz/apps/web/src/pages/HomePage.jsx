
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import ParallaxHero from '@/components/ParallaxHero';
import SmoothScroller from '@/components/SmoothScroller';
import CountdownTimer from '@/components/CountdownTimer';
import LegacySection from '@/components/LegacySection';
import { Calendar, Users, Heart, Gift } from 'lucide-react';

const HomePage = () => {
  const features = [
    {
      icon: Calendar,
      title: 'Reunion 2026',
      description: 'Join us for an unforgettable celebration of family, faith, and heritage.'
    },
    {
      icon: Gift,
      title: 'Raffle baskets',
      description: 'Win amazing prizes with our $1 raffle tickets. Three incredible baskets to choose from.'
    },
    {
      icon: Users,
      title: 'Family portraits',
      description: 'Capture precious memories with professional family portrait sessions.'
    },
    {
      icon: Heart,
      title: 'Our legacy',
      description: 'Discover the rich history and symbolism of the Sumlin Family crest.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Sumlin Family Reunion 2026 - Rooted in Faith, United in Legacy</title>
        <meta name="description" content="Join the Sumlin Family Reunion 2026. Celebrate our heritage, participate in raffle drawings, and create lasting memories with family." />
      </Helmet>

      <ParallaxHero
        backgroundImage="https://horizons-cdn.hostinger.com/6ddbc4c1-b479-4ef4-be4a-ff36b8b1842e/bc40c07d60cdf4a592ad526b10aeddb5.png"
        title="Sumlin Family Reunion 2026"
        tagline="Rooted in Faith, United in Legacy"
        ctaText="Purchase Ticket"
        ctaLink="/family-legacy"
        overlayOpacity={0.5}
      />

      <section className="py-4 md:py-6 lg:py-8 gradient-burgundy-gold relative overflow-hidden shadow-inner">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 mix-blend-overlay pointer-events-none"></div>
        <div className="container-custom relative z-10">
          <SmoothScroller>
            <div className="flex flex-col items-center justify-center text-center">
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-8 tracking-wide drop-shadow-md">
                Countdown to Reunion 2026
              </h2>
              <div className="hero-countdown w-full max-w-4xl mx-auto">
                <CountdownTimer />
              </div>
            </div>
          </SmoothScroller>
        </div>
      </section>

      <section className="section-spacing bg-background">
        <div className="container-custom">
          <SmoothScroller>
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">Welcome to our family</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The Sumlin Family Reunion is more than an event—it's a celebration of our shared heritage, faith, and the bonds that unite us across generations.
              </p>
            </div>
          </SmoothScroller>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {features.map((feature, index) => (
              <SmoothScroller key={index} delay={index * 0.1}>
                <div className="bg-card rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 flex flex-col h-full">
                  <div className="w-16 h-16 rounded-xl gradient-gold flex items-center justify-center mb-6">
                    <feature.icon className="w-8 h-8 text-foreground" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed flex-grow">
                    {feature.description}
                  </p>
                </div>
              </SmoothScroller>
            ))}
          </div>
        </div>
      </section>

      <SmoothScroller>
        <div className="py-4 md:py-6 lg:py-8 bg-background">
          <div className="container-custom">
            <div className="image-separator max-w-sm md:max-w-xl lg:max-w-2xl mx-auto">
              <img
                src="https://horizons-cdn.hostinger.com/6ddbc4c1-b479-4ef4-be4a-ff36b8b1842e/4e13b087f02f8b089679f220666f2c15.png"
                alt="Two vintage black and white family portrait photographs showing historical Sumlin family members"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </SmoothScroller>

      {/* New Legacy Section */}
      <LegacySection />

      <section className="section-spacing bg-muted">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <SmoothScroller direction="left">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-6">The 25-ticket challenge</h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Support our family reunion by purchasing raffle tickets for just $1 each. Every ticket brings you closer to winning one of our three amazing gift baskets while helping fund our celebration.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full gradient-gold flex items-center justify-center text-foreground font-bold text-sm flex-shrink-0 mt-0.5">✓</span>
                    <span>Men's BBQ Basket - Perfect for the grill master</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full gradient-gold flex items-center justify-center text-foreground font-bold text-sm flex-shrink-0 mt-0.5">✓</span>
                    <span>Women's Spa Basket - Relaxation and self-care essentials</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full gradient-gold flex items-center justify-center text-foreground font-bold text-sm flex-shrink-0 mt-0.5">✓</span>
                    <span>Children's Fun Basket - Games, toys, and activities</span>
                  </li>
                </ul>
                <Link
                  to="/family-legacy"
                  className="inline-block gradient-burgundy text-white px-8 py-3 rounded-xl font-semibold hover:shadow-burgundy hover:scale-105 transition-all duration-200 active:scale-[0.98]"
                >
                  Learn more
                </Link>
              </div>
            </SmoothScroller>

            <SmoothScroller direction="right" delay={0.2}>
              <div className="relative">
                <div className="absolute inset-0 gradient-gold rounded-2xl blur-2xl opacity-20" />
                <img
                  src="https://horizons-cdn.hostinger.com/6ddbc4c1-b479-4ef4-be4a-ff36b8b1842e/image-7-KlQC4.png"
                  alt="Sumlin Family Crest representing our heritage and values"
                  className="relative rounded-2xl shadow-2xl w-full"
                />
              </div>
            </SmoothScroller>
          </div>
        </div>
      </section>

      <section className="section-spacing bg-background">
        <div className="container-custom text-center">
          <SmoothScroller>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Join us in 2026</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Be part of a celebration that honors our past, celebrates our present, and builds our future together.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/family-legacy"
                className="inline-block gradient-gold text-foreground px-8 py-3 rounded-xl font-semibold hover:shadow-gold hover:scale-105 transition-all duration-200 active:scale-[0.98]"
              >
                Purchase Ticket
              </Link>
              <Link
                to="/about"
                className="inline-block bg-muted text-foreground px-8 py-3 rounded-xl font-semibold hover:bg-muted/80 hover:scale-105 transition-all duration-200 active:scale-[0.98]"
              >
                Learn our story
              </Link>
            </div>
          </SmoothScroller>
        </div>
      </section>
    </>
  );
};

export default HomePage;
